"""
CDC (Change Data Capture) Module

This module provides components for extracting and processing change data
from the operational database for downstream processing.
"""
