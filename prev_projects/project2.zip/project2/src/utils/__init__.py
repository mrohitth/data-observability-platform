"""
Utilities Module

This module provides shared utilities for the CDC platform,
including logging configuration, signal handling, and common helper functions.
"""
