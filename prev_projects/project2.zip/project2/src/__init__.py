"""
CDC Simulation Platform Source Package

This package contains the core components for the CDC simulation platform,
including database mutators and change data extractors.
"""
