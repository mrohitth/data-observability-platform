"""
Tests Module

This module contains validation and testing scripts for the CDC simulation platform,
including SCD Type 2 validation and lineage tracking.
"""
