-- Initialize Analytics Warehouse Database
-- This script creates the warehouse database with required schemas

-- Create schemas if they don't exist
CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS staging;
CREATE SCHEMA IF NOT EXISTS marts;

-- Set schema permissions for the airflow user
GRANT ALL ON SCHEMA raw TO airflow;
GRANT ALL ON SCHEMA staging TO airflow;
GRANT ALL ON SCHEMA marts TO airflow;

-- Grant usage on schemas
GRANT USAGE ON SCHEMA raw TO airflow;
GRANT USAGE ON SCHEMA staging TO airflow;
GRANT USAGE ON SCHEMA marts TO airflow;

-- Create default privileges for future objects
ALTER DEFAULT PRIVILEGES IN SCHEMA raw GRANT ALL ON TABLES TO airflow;
ALTER DEFAULT PRIVILEGES IN SCHEMA staging GRANT ALL ON TABLES TO airflow;
ALTER DEFAULT PRIVILEGES IN SCHEMA marts GRANT ALL ON TABLES TO airflow;

-- Create comments for documentation
COMMENT ON SCHEMA raw IS 'Raw data landing zone - ingested data in original format';
COMMENT ON SCHEMA staging IS 'Staging area - cleaned and transformed intermediate data';
COMMENT ON SCHEMA marts IS 'Data marts - business-ready aggregated data for analytics';

-- Log initialization
DO $$
BEGIN
    RAISE NOTICE 'Analytics Warehouse initialized successfully at %', NOW();
    RAISE NOTICE 'Created schemas: raw, staging, marts';
END $$;
