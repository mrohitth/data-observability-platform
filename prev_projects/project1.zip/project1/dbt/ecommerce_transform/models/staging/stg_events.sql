-- Staging model for e-commerce events
-- Deduplicates events and cleans up JSON data

{{ config(
    materialized='table',
    schema='staging'
) }}

WITH deduplicated_events AS (
    SELECT 
        (data->>'event_id')::varchar AS event_id,
        (data->>'event_type')::varchar AS event_type,
        (data->>'timestamp')::timestamp AS timestamp,
        data,
        ROW_NUMBER() OVER (
            PARTITION BY (data->>'event_id') 
            ORDER BY (data->>'timestamp')::timestamp DESC, 
                     CASE WHEN (data->>'event_type') = 'order_cancelled' THEN 1 ELSE 2 END
        ) AS rn
    FROM {{ source('raw_source', 'events_stream') }}
),

parsed_events AS (
    SELECT 
        event_id,
        event_type,
        timestamp AS event_timestamp,
        
        -- Parse common fields from JSON
        (data->>'user_id')::varchar AS user_id,
        (data->>'order_id')::varchar AS order_id,
        (data->>'email')::varchar AS email,
        (data->>'first_name')::varchar AS first_name,
        (data->>'last_name')::varchar AS last_name,
        (data->>'age')::integer AS age,
        (data->>'city')::varchar AS city,
        (data->>'registration_source')::varchar AS registration_source,
        (data->>'payment_method')::varchar AS payment_method,
        (data->>'status')::varchar AS status,
        (data->>'cancellation_reason')::varchar AS cancellation_reason,
        
        -- Parse numeric fields
        (data->>'total_amount')::numeric(10,2) AS total_amount,
        (data->>'refund_amount')::numeric(10,2) AS refund_amount,
        
        -- Parse product-related fields
        (data->>'product_id')::varchar AS product_id,
        (data->>'name')::varchar AS product_name,
        (data->>'category')::varchar AS product_category,
        (data->>'price')::numeric(10,2) AS product_price,
        (data->>'stock')::integer AS product_stock,
        (data->>'updated_fields')::varchar AS updated_fields,
        
        -- Parse items array for order events
        data->'items' AS items_array,
        
        -- Raw data for debugging
        data AS raw_data
        
    FROM deduplicated_events
    WHERE rn = 1  -- Only keep the latest version of each event
)

SELECT 
    event_id,
    event_type,
    event_timestamp,
    user_id,
    order_id,
    email,
    first_name,
    last_name,
    age,
    city,
    registration_source,
    payment_method,
    status,
    cancellation_reason,
    total_amount,
    refund_amount,
    product_id,
    product_name,
    product_category,
    product_price,
    product_stock,
    updated_fields,
    items_array,
    raw_data
FROM parsed_events
