-- Order fact table
-- Contains order events joined with user dimension

{{ config(
    materialized='table',
    schema='marts'
) }}

WITH order_events AS (
    SELECT 
        event_id,
        order_id,
        user_id,
        event_timestamp,
        total_amount,
        payment_method,
        status,
        items_array,
        raw_data
    FROM {{ ref('stg_events') }}
    WHERE event_type = 'order_created'
        AND order_id IS NOT NULL
),

order_items AS (
    SELECT 
        event_id,
        order_id,
        user_id,
        event_timestamp,
        total_amount,
        payment_method,
        status,
        item->>'product_id' AS product_id,
        (item->>'quantity')::integer AS quantity,
        (item->>'unit_price')::numeric(10,2) AS unit_price,
        (item->>'total_price')::numeric(10,2) AS total_price
    FROM order_events,
    LATERAL jsonb_array_elements(items_array) AS item
),

user_dimension AS (
    SELECT 
        user_id,
        email,
        first_name,
        last_name,
        city,
        registration_source
    FROM {{ ref('dim_users') }}
)

SELECT 
    oe.event_id,
    oe.order_id,
    oe.user_id,
    ud.email AS user_email,
    ud.first_name AS user_first_name,
    ud.last_name AS user_last_name,
    ud.city AS user_city,
    ud.registration_source AS user_registration_source,
    oe.event_timestamp AS order_timestamp,
    oe.total_amount AS order_total_amount,
    oe.payment_method,
    oe.status AS order_status,
    oi.product_id,
    oi.quantity,
    oi.unit_price,
    oi.total_price AS item_total_price,
    CURRENT_TIMESTAMP AS dw_loaded_at
FROM order_events oe
LEFT JOIN user_dimension ud 
    ON oe.user_id = ud.user_id
LEFT JOIN order_items oi 
    ON oe.event_id = oi.event_id
