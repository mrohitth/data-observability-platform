-- User dimension table
-- Contains unique users with their latest metadata

{{ config(
    materialized='table',
    schema='marts'
) }}

WITH user_events AS (
    SELECT 
        user_id,
        email,
        first_name,
        last_name,
        age,
        city,
        registration_source,
        event_timestamp,
        event_type
    FROM {{ ref('stg_events') }}
    WHERE user_id IS NOT NULL
),

user_registrations AS (
    SELECT 
        user_id,
        email,
        first_name,
        last_name,
        age,
        city,
        registration_source,
        event_timestamp AS registration_timestamp
    FROM user_events
    WHERE event_type = 'user_registered'
),

latest_user_updates AS (
    SELECT 
        user_id,
        email,
        first_name,
        last_name,
        age,
        city,
        registration_source,
        event_timestamp AS last_updated_timestamp,
        ROW_NUMBER() OVER (
            PARTITION BY user_id 
            ORDER BY event_timestamp DESC
        ) AS rn
    FROM user_events
)

SELECT 
    COALESCE(reg.user_id, upd.user_id) AS user_id,
    COALESCE(reg.email, upd.email) AS email,
    COALESCE(reg.first_name, upd.first_name) AS first_name,
    COALESCE(reg.last_name, upd.last_name) AS last_name,
    COALESCE(reg.age, upd.age) AS age,
    COALESCE(reg.city, upd.city) AS city,
    COALESCE(reg.registration_source, upd.registration_source) AS registration_source,
    reg.registration_timestamp,
    upd.last_updated_timestamp,
    CURRENT_TIMESTAMP AS dw_updated_at
FROM user_registrations reg
FULL OUTER JOIN latest_user_updates upd 
    ON reg.user_id = upd.user_id AND upd.rn = 1
WHERE COALESCE(reg.user_id, upd.user_id) IS NOT NULL
