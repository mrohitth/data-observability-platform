-- Deduplication metrics model
-- Calculates deduplication efficiency metrics for the dashboard

{{ config(
    materialized='table',
    schema='marts'
) }}

WITH raw_counts AS (
    SELECT 
        COUNT(*) AS raw_record_count,
        COUNT(DISTINCT id) AS raw_unique_count
    FROM {{ source('raw_source', 'events_stream') }}
),

dedup_counts AS (
    SELECT 
        COUNT(*) AS dedup_record_count,
        COUNT(DISTINCT event_id) AS dedup_unique_count
    FROM {{ ref('stg_events') }}
)

SELECT 
    -- Raw counts
    raw_counts.raw_record_count,
    raw_counts.raw_unique_count,
    
    -- Deduplicated counts
    dedup_counts.dedup_record_count,
    dedup_counts.dedup_unique_count,
    
    -- Deduplication efficiency calculations
    ((raw_counts.raw_record_count - dedup_counts.dedup_unique_count)::numeric / raw_counts.raw_record_count) * 100 AS deduplication_efficiency_pct,
    
    -- Additional metrics
    (raw_counts.raw_record_count - dedup_counts.dedup_unique_count) AS duplicates_removed,
    
    -- Quality indicators
    CASE 
        WHEN raw_counts.raw_record_count = 0 THEN 0
        WHEN dedup_counts.dedup_unique_count = 0 THEN 100
        ELSE ((raw_counts.raw_record_count - dedup_counts.dedup_unique_count)::numeric / raw_counts.raw_record_count) * 100
    END AS data_quality_score,
    
    -- Timestamps
    CURRENT_TIMESTAMP AS metrics_calculated_at

FROM raw_counts, dedup_counts
