#!/usr/bin/env python3
"""
Simple HTTP server to serve the analytics dashboard.
"""

import http.server
import socketserver
import os
import json
from pathlib import Path

PORT = 8082
DOCS_DIR = "/opt/airflow/docs"

class DashboardHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DOCS_DIR, **kwargs)
    
    def end_headers(self):
        # Add CORS headers
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()
    
    def do_GET(self):
        # Serve index.html for root path
        if self.path == '/':
            self.path = '/index.html'
        
        # Check if website_data.json exists, if not create a sample
        if self.path == '/website_data.json':
            json_file = Path(DOCS_DIR) / 'website_data.json'
            if not json_file.exists():
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                
                # Sample data for when pipeline hasn't run yet
                sample_data = {
                    "last_updated": "2024-01-01T00:00:00",
                    "kpis": {
                        "raw": {
                            "total_revenue": 1699692.00,
                            "total_orders": 1000,
                            "total_records": 1150,
                            "unique_records": 1000
                        },
                        "cleaned": {
                            "total_revenue": 9792642.00,
                            "total_orders": 5000,
                            "total_records": 1000,
                            "unique_records": 1000
                        },
                        "deduplication_efficiency": {
                            "raw_records": 1150,
                            "dedup_records": 1000,
                            "efficiency_pct": 13.0,
                            "duplicates_removed": 150
                        },
                        "comparison": {
                            "revenue_delta": -8092950.00,
                            "duplicate_count": 150
                        }
                    },
                    "daily_revenue": {
                        "raw": [
                            {"date": "2024-01-01", "revenue": 200000.00},
                            {"date": "2024-01-02", "revenue": 250000.00}
                        ],
                        "cleaned": [
                            {"date": "2024-01-01", "revenue": 1200000.00},
                            {"date": "2024-01-02", "revenue": 1500000.00}
                        ]
                    },
                    "category_split": [
                        {"category": "Electronics", "revenue": 5000000.00}
                    ],
                    "deduplication_logic": "WITH deduplicated_events AS (...)\nSELECT * FROM deduplicated_events WHERE rn = 1"
                }
                
                self.wfile.write(json.dumps(sample_data, indent=2).encode())
                return
        
        return super().do_GET()

if __name__ == "__main__":
    # Ensure docs directory exists
    os.makedirs(DOCS_DIR, exist_ok=True)
    
    # Create sample index.html if it doesn't exist
    index_file = Path(DOCS_DIR) / 'index.html'
    if not index_file.exists():
        print(f"⚠️  Warning: {index_file} not found. Please run the pipeline first.")
        print("📁 Creating a placeholder file...")
        with open(index_file, 'w') as f:
            f.write("""<!DOCTYPE html>
<html>
<head><title>Analytics Dashboard</title></head>
<body>
    <h1>🚀 Analytics Dashboard</h1>
    <p>Please run the data pipeline first:</p>
    <pre>
docker exec analytics_airflow airflow dags trigger ingest_ecommerce_data
python scripts/export_site_data.py
    </pre>
</body>
</html>""")
    
    with socketserver.TCPServer(("", PORT), DashboardHandler) as httpd:
        print(f"🚀 Dashboard server running at http://localhost:{PORT}")
        print(f"📁 Serving files from: {DOCS_DIR}")
        httpd.serve_forever()
