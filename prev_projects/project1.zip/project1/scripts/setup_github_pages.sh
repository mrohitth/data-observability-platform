#!/bin/bash
# GitHub Pages Setup Script
# This script helps prepare the docs/ folder for GitHub Pages deployment

echo "🚀 Setting up GitHub Pages deployment..."

# Ensure docs folder exists
mkdir -p docs

# Create .nojekyll file (optional but recommended)
touch docs/.nojekyll

echo "✅ GitHub Pages setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Run the pipeline to generate data: docker exec analytics_airflow airflow dags trigger ingest_ecommerce_data"
echo "2. Export dashboard data: python scripts/export_site_data.py"
echo "3. Commit and push your changes to GitHub"
echo "4. Go to your repository settings"
echo "5. Enable GitHub Pages from the 'docs/' folder"
echo "6. Your dashboard will be available at: https://[username].github.io/[repository]/"
echo ""
echo "🔗 Note: The dashboard will display sample data until the pipeline is run."
