#!/usr/bin/env python3
"""
Export analytics data for the website dashboard.
Queries the analytics schema to extract KPIs and metrics for visualization.
"""

import json
import psycopg2
import os
from datetime import datetime, timedelta
from typing import Dict, Any

def get_db_connection():
    """Establish connection to PostgreSQL database."""
    # Use localhost when running outside Docker, postgres when inside
    host = os.environ.get('POSTGRES_HOST', 'localhost')
    if host == 'localhost':
        host = 'localhost'
        port = 5432
        user = 'airflow'
        password = 'airflow'
        database = 'warehouse'
    else:
        host = 'postgres'
        port = 5432
        user = 'airflow'
        password = 'airflow'
        database = 'warehouse'
    
    return psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )

def get_kpis(conn) -> Dict[str, Any]:
    """Calculate key performance indicators for both raw and cleaned data."""
    with conn.cursor() as cursor:
        # Raw metrics (before dbt transformations)
        cursor.execute("""
            SELECT 
                COUNT(*) as raw_record_count,
                COUNT(DISTINCT id) as raw_unique_count
            FROM raw.events_stream
        """)
        raw_count, raw_unique_count = cursor.fetchone()
        
        # Raw revenue calculation (from raw events)
        cursor.execute("""
            SELECT 
                COALESCE(SUM((data->>'total_amount')::decimal), 0) as raw_revenue,
                COUNT(DISTINCT data->>'order_id') as raw_orders
            FROM raw.events_stream
            WHERE data->>'event_type' = 'order_created'
                AND data->>'total_amount' IS NOT NULL
        """)
        raw_revenue, raw_orders = cursor.fetchone()
        
        # Cleaned metrics (from dbt models)
        cursor.execute("""
            SELECT 
                COALESCE(SUM(item_total_price), 0) as total_revenue
            FROM analytics_marts.fact_orders
            WHERE order_status = 'confirmed'
        """)
        total_revenue = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(DISTINCT order_id) as total_orders
            FROM analytics_marts.fact_orders
            WHERE order_status = 'confirmed'
        """)
        total_orders = cursor.fetchone()[0]
        
        # Deduplication metrics
        cursor.execute("""
            SELECT 
                raw_record_count,
                dedup_unique_count,
                deduplication_efficiency_pct,
                duplicates_removed
            FROM analytics_marts.int_deduplication_metrics
            ORDER BY metrics_calculated_at DESC
            LIMIT 1
        """)
        result = cursor.fetchone()
        if result:
            dedup_raw_count, dedup_count, dedup_efficiency, duplicates_removed = result
        else:
            # Fallback calculation
            dedup_raw_count = raw_count
            dedup_count = raw_unique_count
            dedup_efficiency = 0.0
            duplicates_removed = 0
        
        # Calculate comparison metrics
        revenue_delta = raw_revenue - total_revenue
        duplicate_count = duplicates_removed
        
        return {
            "raw": {
                "total_revenue": float(raw_revenue),
                "total_orders": int(raw_orders),
                "total_records": int(raw_count),
                "unique_records": int(raw_unique_count)
            },
            "cleaned": {
                "total_revenue": float(total_revenue),
                "total_orders": int(total_orders),
                "total_records": int(dedup_count),
                "unique_records": int(dedup_count)
            },
            "deduplication_efficiency": {
                "raw_records": int(dedup_raw_count),
                "dedup_records": int(dedup_count),
                "efficiency_pct": float(dedup_efficiency),
                "duplicates_removed": int(duplicates_removed)
            },
            "comparison": {
                "revenue_delta": float(revenue_delta),
                "duplicate_count": int(duplicate_count)
            }
        }

def get_daily_revenue(conn) -> list:
    """Get daily revenue breakdown for the last 7 days for both raw and cleaned data."""
    with conn.cursor() as cursor:
        # Cleaned daily revenue (from dbt models)
        cursor.execute("""
            SELECT 
                DATE(order_timestamp) as date,
                SUM(item_total_price) as revenue
            FROM analytics_marts.fact_orders
            WHERE order_status = 'confirmed'
                AND DATE(order_timestamp) >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY DATE(order_timestamp)
            ORDER BY date ASC
        """)
        
        cleaned_results = cursor.fetchall()
        cleaned_daily = [
            {
                "date": row[0].strftime('%Y-%m-%d'),
                "revenue": float(row[1])
            }
            for row in cleaned_results
        ]
        
        # Raw daily revenue (from raw events)
        cursor.execute("""
            SELECT 
                DATE((data->>'timestamp')::timestamp) as date,
                SUM((data->>'total_amount')::decimal) as revenue
            FROM raw.events_stream
            WHERE data->>'event_type' = 'order_created'
                AND data->>'total_amount' IS NOT NULL
                AND DATE((data->>'timestamp')::timestamp) >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY DATE((data->>'timestamp')::timestamp)
            ORDER BY date ASC
        """)
        
        raw_results = cursor.fetchall()
        raw_daily = [
            {
                "date": row[0].strftime('%Y-%m-%d'),
                "revenue": float(row[1])
            }
            for row in raw_results
        ]
        
        return {
            "raw": raw_daily,
            "cleaned": cleaned_daily
        }

def get_category_split(conn) -> list:
    """Get revenue breakdown by product category."""
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT 
                'Electronics' as category,
                SUM((data->>'total_amount')::decimal) as revenue
            FROM raw.events_stream
            WHERE data->>'event_type' = 'order_created'
                AND data->>'total_amount' IS NOT NULL
        """)
        
        results = cursor.fetchall()
        return [
            {
                "category": row[0],
                "revenue": float(row[1])
            }
            for row in results if row[1] > 0
        ]

def get_deduplication_logic() -> str:
    """Return the deduplication SQL logic for display."""
    return """
WITH deduplicated_events AS (
    SELECT 
        (data->>'event_id')::varchar AS event_id,
        (data->>'event_type')::varchar AS event_type,
        (data->>'timestamp')::timestamp AS timestamp,
        data,
        ROW_NUMBER() OVER (
            PARTITION BY (data->>'event_id') 
            ORDER BY (data->>'timestamp')::timestamp DESC, 
                     CASE WHEN (data->>'event_type') = 'order_cancelled' THEN 1 ELSE 2 END
        ) AS rn
    FROM {{ source('raw_source', 'events_stream') }}
)
SELECT * FROM deduplicated_events WHERE rn = 1
    """.strip()

def validate_data_availability(conn):
    """Validate that required tables have data before export."""
    with conn.cursor() as cursor:
        # Check raw.events_stream has data
        cursor.execute("SELECT COUNT(*) FROM raw.events_stream")
        raw_count = cursor.fetchone()[0]
        
        # Check analytics_staging.stg_events has data
        cursor.execute("SELECT COUNT(*) FROM analytics_staging.stg_events")
        staging_count = cursor.fetchone()[0]
        
        # Check analytics_marts.fact_orders has data
        cursor.execute("SELECT COUNT(*) FROM analytics_marts.fact_orders WHERE order_status = 'confirmed'")
        fact_count = cursor.fetchone()[0]
        
        # Validate data availability
        if raw_count == 0:
            raise ValueError("❌ Validation Failed: raw.events_stream table is empty. No data to export.")
        
        if staging_count == 0:
            raise ValueError("❌ Validation Failed: analytics_staging.stg_events table is empty. Transformation may have failed.")
        
        if fact_count == 0:
            raise ValueError("❌ Validation Failed: analytics_marts.fact_orders table has no confirmed orders. Pipeline may have failed.")
        
        print(f"✅ Data validation passed: {raw_count} raw records, {staging_count} staged records, {fact_count} fact records")
        return True

def main():
    """Main export function."""
    print("🔄 Exporting analytics data for website dashboard...")
    
    try:
        # Connect to database
        conn = get_db_connection()
        
        # Validate data availability first
        validate_data_availability(conn)
        
        # Gather all data
        kpis = get_kpis(conn)
        daily_revenue = get_daily_revenue(conn)
        category_split = get_category_split(conn)
        deduplication_logic = get_deduplication_logic()
        
        # Additional validation for query results
        if not daily_revenue["cleaned"]:
            raise ValueError("❌ Validation Failed: Daily revenue query returned no data. Check date range and data availability.")
        
        if not category_split:
            print("⚠️  Warning: Category split query returned no data. This may indicate missing product categories.")
        
        # Prepare final data structure
        website_data = {
            "last_updated": datetime.now().isoformat(),
            "kpis": kpis,
            "daily_revenue": daily_revenue,
            "category_split": category_split,
            "deduplication_logic": deduplication_logic
        }
        
        # Ensure docs directory exists
        import os
        os.makedirs('docs', exist_ok=True)
        
        # Save to JSON file
        with open('docs/website_data.json', 'w') as f:
            json.dump(website_data, f, indent=2, default=str)
        
        print(f"✅ Data exported successfully to docs/website_data.json")
        print(f"📊 Raw KPIs: ${kpis['raw']['total_revenue']:,.2f} revenue, {kpis['raw']['total_orders']:,} orders")
        print(f"📊 Cleaned KPIs: ${kpis['cleaned']['total_revenue']:,.2f} revenue, {kpis['cleaned']['total_orders']:,} orders")
        print(f"🔍 Deduplication: {kpis['deduplication_efficiency']['efficiency_pct']:.1f}% efficiency")
        print(f"📈 Daily revenue points: {len(daily_revenue['cleaned'])}")
        print(f"🏷️  Categories: {len(category_split)}")
        
    except ValueError as validation_error:
        print(f"❌ Data validation failed: {validation_error}")
        raise
    except Exception as e:
        print(f"❌ Error exporting data: {e}")
        raise
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    main()
