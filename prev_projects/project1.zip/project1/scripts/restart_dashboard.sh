#!/bin/bash
# Quick dashboard restart script

echo "🔄 Restarting dashboard service..."

# Restart just the dashboard container
docker-compose restart dashboard

echo "✅ Dashboard restarted!"
echo "🌐 Dashboard available at: http://localhost:8082"
echo "📊 Airflow UI available at: http://localhost:8080"
