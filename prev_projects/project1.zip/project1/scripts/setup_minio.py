#!/usr/bin/env python3
"""
MinIO Bucket Setup Script
Ensures the raw-data bucket exists in MinIO for data ingestion.
"""

import json
import logging
import sys
from urllib.parse import urlparse

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
except ImportError:
    print("Error: boto3 is required. Install with: pip install boto3")
    sys.exit(1)


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MinIOSetup:
    """Handles MinIO bucket initialization and configuration."""
    
    def __init__(self, endpoint_url: str, access_key: str, secret_key: str):
        """
        Initialize MinIO client.
        
        Args:
            endpoint_url: MinIO endpoint URL (e.g., http://localhost:9000)
            access_key: MinIO access key
            secret_key: MinIO secret key
        """
        self.client = boto3.client(
            's3',
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name='us-east-1'  # MinIO doesn't use regions but this is required
        )
        self.bucket_name = 'raw-data'
        
    def test_connection(self) -> bool:
        """Test connection to MinIO."""
        try:
            # List buckets to test connection
            response = self.client.list_buckets()
            logger.info("Successfully connected to MinIO")
            logger.info(f"Existing buckets: {[bucket['Name'] for bucket in response['Buckets']]}")
            return True
        except (ClientError, NoCredentialsError) as e:
            logger.error(f"Failed to connect to MinIO: {e}")
            return False
    
    def bucket_exists(self) -> bool:
        """Check if the raw-data bucket exists."""
        try:
            self.client.head_bucket(Bucket=self.bucket_name)
            logger.info(f"Bucket '{self.bucket_name}' already exists")
            return True
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == '404':
                logger.info(f"Bucket '{self.bucket_name}' does not exist")
                return False
            else:
                logger.error(f"Error checking bucket existence: {e}")
                return False
    
    def create_bucket(self) -> bool:
        """Create the raw-data bucket."""
        try:
            self.client.create_bucket(Bucket=self.bucket_name)
            logger.info(f"Successfully created bucket '{self.bucket_name}'")
            return True
        except ClientError as e:
            logger.error(f"Failed to create bucket '{self.bucket_name}': {e}")
            return False
    
    def setup_bucket_policies(self) -> bool:
        """Set up bucket policies for data access."""
        try:
            # Create a simple bucket policy that allows read/write access
            bucket_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "PublicReadWrite",
                        "Effect": "Allow",
                        "Principal": "*",
                        "Action": [
                            "s3:GetObject",
                            "s3:PutObject",
                            "s3:DeleteObject",
                            "s3:ListBucket"
                        ],
                        "Resource": [
                            f"arn:aws:s3:::{self.bucket_name}",
                            f"arn:aws:s3:::{self.bucket_name}/*"
                        ]
                    }
                ]
            }
            
            self.client.put_bucket_policy(
                Bucket=self.bucket_name,
                Policy=json.dumps(bucket_policy)
            )
            logger.info(f"Successfully set bucket policy for '{self.bucket_name}'")
            return True
        except ClientError as e:
            logger.warning(f"Failed to set bucket policy (bucket might still work): {e}")
            return False
    
    def create_folder_structure(self) -> bool:
        """Create initial folder structure in the bucket."""
        try:
            # Create folders for different data types
            folders = [
                'events/',
                'events/orders/',
                'events/users/',
                'events/products/',
                'archive/',
                'processed/'
            ]
            
            for folder in folders:
                self.client.put_object(
                    Bucket=self.bucket_name,
                    Key=folder,
                    Body=b'',
                    ContentLength=0
                )
                logger.info(f"Created folder: {folder}")
            
            return True
        except ClientError as e:
            logger.warning(f"Failed to create folder structure: {e}")
            return False
    
    def setup(self) -> bool:
        """Complete MinIO setup process."""
        logger.info("Starting MinIO setup...")
        
        # Test connection
        if not self.test_connection():
            return False
        
        # Check if bucket exists, create if not
        if not self.bucket_exists():
            if not self.create_bucket():
                return False
        
        # Set up bucket policies
        self.setup_bucket_policies()
        
        # Create folder structure
        self.create_folder_structure()
        
        logger.info("MinIO setup completed successfully!")
        return True


def main():
    """Main function to run MinIO setup."""
    import json
    
    # MinIO connection details (matching docker-compose.yml)
    minio_config = {
        'endpoint_url': 'http://localhost:9000',
        'access_key': 'minioadmin',
        'secret_key': 'minioadmin'
    }
    
    logger.info("Setting up MinIO bucket for data ingestion...")
    logger.info(f"Endpoint: {minio_config['endpoint_url']}")
    logger.info(f"Access Key: {minio_config['access_key']}")
    
    # Initialize and run setup
    setup = MinIOSetup(**minio_config)
    
    if setup.setup():
        logger.info("✅ MinIO is ready for data ingestion!")
        sys.exit(0)
    else:
        logger.error("❌ MinIO setup failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()
