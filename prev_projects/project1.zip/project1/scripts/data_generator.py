#!/usr/bin/env python3
"""
Synthetic E-commerce Data Generator
Generates realistic e-commerce events (orders, users, product updates) with data noise.
"""

import argparse
import json
import random
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any
import sys


class EcommerceDataGenerator:
    """Generates synthetic e-commerce events with realistic patterns and noise."""
    
    def __init__(self, target_date: str):
        self.target_date = datetime.strptime(target_date, "%Y-%m-%d")
        self.event_types = ["order_created", "user_registered", "product_updated", "order_cancelled"]
        self.products = self._generate_product_catalog()
        self.users = []
        self.generated_event_ids = set()
        
    def _generate_product_catalog(self) -> List[Dict[str, Any]]:
        """Generate a realistic product catalog."""
        categories = ["Electronics", "Clothing", "Home", "Books", "Sports", "Beauty"]
        products = []
        
        for i in range(100):
            product = {
                "product_id": f"PROD_{i+1:04d}",
                "name": f"Product {i+1}",
                "category": random.choice(categories),
                "price": round(random.uniform(10.0, 500.0), 2),
                "stock": random.randint(0, 1000),
                "created_at": (self.target_date - timedelta(days=random.randint(1, 365))).isoformat()
            }
            products.append(product)
            
        return products
    
    def _generate_user(self) -> Dict[str, Any]:
        """Generate a realistic user profile."""
        user_id = f"USER_{len(self.users)+1:04d}"
        user = {
            "user_id": user_id,
            "email": f"user{len(self.users)+1}@example.com",
            "first_name": random.choice(["John", "Jane", "Mike", "Sarah", "David", "Emily", "Chris", "Lisa"]),
            "last_name": random.choice(["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis"]),
            "age": random.randint(18, 75),
            "city": random.choice(["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia"]),
            "registration_date": self.target_date.isoformat()
        }
        self.users.append(user)
        return user
    
    def _generate_order_event(self) -> Dict[str, Any]:
        """Generate an order event with realistic data."""
        event_id = str(uuid.uuid4())
        
        # Introduce 15% duplicate event_ids for noise
        if random.random() < 0.15 and self.generated_event_ids:
            event_id = random.choice(list(self.generated_event_ids))
            # Slightly modify timestamp for some duplicates (30% chance)
            if random.random() < 0.3:
                base_timestamp = self._generate_random_timestamp()
                # Add small time offset (1-60 seconds) to simulate near-duplicate events
                offset_seconds = random.randint(1, 60)
                modified_timestamp = datetime.fromisoformat(base_timestamp.replace('Z', '+00:00'))
                modified_timestamp += timedelta(seconds=offset_seconds)
                # Store modified timestamp for later use
                self._modified_timestamp = modified_timestamp.isoformat()
        else:
            self.generated_event_ids.add(event_id)
        
        user = random.choice(self.users) if self.users else self._generate_user()
        num_items = random.randint(1, 5)
        order_items = []
        
        for _ in range(num_items):
            product = random.choice(self.products)
            quantity = random.randint(1, 3)
            order_items.append({
                "product_id": product["product_id"],
                "quantity": quantity,
                "unit_price": product["price"],
                "total_price": round(product["price"] * quantity, 2)
            })
        
        total_amount = sum(item["total_price"] for item in order_items)
        
        event = {
            "event_id": event_id,
            "event_type": "order_created",
            "timestamp": getattr(self, '_modified_timestamp', self._generate_random_timestamp()),
            "order_id": f"ORD_{random.randint(10000, 99999)}",
            "user_id": user["user_id"],
            "items": order_items,
            "total_amount": round(total_amount, 2),
            "payment_method": random.choice(["credit_card", "paypal", "apple_pay", "google_pay"]),
            "status": "confirmed"
        }
        
        # Clear modified timestamp after use
        if hasattr(self, '_modified_timestamp'):
            delattr(self, '_modified_timestamp')
        
        # Introduce missing optional fields (10% chance)
        if random.random() < 0.1:
            event.pop("payment_method", None)
        
        return event
    
    def _generate_user_event(self) -> Dict[str, Any]:
        """Generate a user registration event."""
        event_id = str(uuid.uuid4())
        
        # Introduce 15% duplicate event_ids for noise
        if random.random() < 0.15 and self.generated_event_ids:
            event_id = random.choice(list(self.generated_event_ids))
            # Slightly modify timestamp for some duplicates (30% chance)
            if random.random() < 0.3:
                base_timestamp = self._generate_random_timestamp()
                # Add small time offset (1-60 seconds) to simulate near-duplicate events
                offset_seconds = random.randint(1, 60)
                modified_timestamp = datetime.fromisoformat(base_timestamp.replace('Z', '+00:00'))
                modified_timestamp += timedelta(seconds=offset_seconds)
                # Store modified timestamp for later use
                self._modified_timestamp = modified_timestamp.isoformat()
        else:
            self.generated_event_ids.add(event_id)
        
        user = self._generate_user()
        
        event = {
            "event_id": event_id,
            "event_type": "user_registered",
            "timestamp": getattr(self, '_modified_timestamp', self._generate_random_timestamp()),
            "user_id": user["user_id"],
            "email": user["email"],
            "first_name": user["first_name"],
            "last_name": user["last_name"],
            "age": user["age"],
            "city": user["city"],
            "registration_source": random.choice(["web", "mobile_app", "social_media", "referral"])
        }
        
        # Clear modified timestamp after use
        if hasattr(self, '_modified_timestamp'):
            delattr(self, '_modified_timestamp')
        
        # Introduce missing optional fields (15% chance)
        if random.random() < 0.15:
            event.pop("age", None)
        if random.random() < 0.15:
            event.pop("city", None)
        
        return event
    
    def _generate_product_event(self) -> Dict[str, Any]:
        """Generate a product update event."""
        event_id = str(uuid.uuid4())
        
        # Introduce 15% duplicate event_ids for noise
        if random.random() < 0.15 and self.generated_event_ids:
            event_id = random.choice(list(self.generated_event_ids))
            # Slightly modify timestamp for some duplicates (30% chance)
            if random.random() < 0.3:
                base_timestamp = self._generate_random_timestamp()
                # Add small time offset (1-60 seconds) to simulate near-duplicate events
                offset_seconds = random.randint(1, 60)
                modified_timestamp = datetime.fromisoformat(base_timestamp.replace('Z', '+00:00'))
                modified_timestamp += timedelta(seconds=offset_seconds)
                # Store modified timestamp for later use
                self._modified_timestamp = modified_timestamp.isoformat()
        else:
            self.generated_event_ids.add(event_id)
        
        product = random.choice(self.products)
        
        # Update product data
        product["price"] = round(product["price"] * random.uniform(0.9, 1.1), 2)
        product["stock"] = max(0, product["stock"] + random.randint(-50, 100))
        product["updated_at"] = self._generate_random_timestamp()
        
        event = {
            "event_id": event_id,
            "event_type": "product_updated",
            "timestamp": getattr(self, '_modified_timestamp', self._generate_random_timestamp()),
            "product_id": product["product_id"],
            "name": product["name"],
            "category": product["category"],
            "price": product["price"],
            "stock": product["stock"],
            "updated_fields": random.choice(["price", "stock", "price,stock"])
        }
        
        # Clear modified timestamp after use
        if hasattr(self, '_modified_timestamp'):
            delattr(self, '_modified_timestamp')
        
        # Introduce missing optional fields (8% chance)
        if random.random() < 0.08:
            event.pop("updated_fields", None)
        
        return event
    
    def _generate_cancelled_order_event(self) -> Dict[str, Any]:
        """Generate an order cancellation event."""
        event_id = str(uuid.uuid4())
        
        # Introduce 15% duplicate event_ids for noise
        if random.random() < 0.15 and self.generated_event_ids:
            event_id = random.choice(list(self.generated_event_ids))
            # Slightly modify timestamp for some duplicates (30% chance)
            if random.random() < 0.3:
                base_timestamp = self._generate_random_timestamp()
                # Add small time offset (1-60 seconds) to simulate near-duplicate events
                offset_seconds = random.randint(1, 60)
                modified_timestamp = datetime.fromisoformat(base_timestamp.replace('Z', '+00:00'))
                modified_timestamp += timedelta(seconds=offset_seconds)
                # Store modified timestamp for later use
                self._modified_timestamp = modified_timestamp.isoformat()
        else:
            self.generated_event_ids.add(event_id)
        
        user = random.choice(self.users) if self.users else self._generate_user()
        
        event = {
            "event_id": event_id,
            "event_type": "order_cancelled",
            "timestamp": getattr(self, '_modified_timestamp', self._generate_random_timestamp()),
            "order_id": f"ORD_{random.randint(10000, 99999)}",
            "user_id": user["user_id"],
            "cancellation_reason": random.choice(["customer_request", "fraud_detected", "inventory_issue", "payment_failed"]),
            "refund_amount": round(random.uniform(10.0, 500.0), 2)
        }
        
        # Clear modified timestamp after use
        if hasattr(self, '_modified_timestamp'):
            delattr(self, '_modified_timestamp')
        
        # Introduce missing optional fields (20% chance)
        if random.random() < 0.2:
            event.pop("cancellation_reason", None)
        
        return event
    
    def _generate_random_timestamp(self) -> str:
        """Generate a random timestamp within the target date."""
        # Random time during the day
        hours = random.randint(0, 23)
        minutes = random.randint(0, 59)
        seconds = random.randint(0, 59)
        
        timestamp = self.target_date.replace(
            hour=hours,
            minute=minutes,
            second=seconds,
            microsecond=random.randint(0, 999999)
        )
        
        return timestamp.isoformat()
    
    def generate_events(self, num_events: int = 1000) -> List[Dict[str, Any]]:
        """Generate specified number of events."""
        events = []
        
        # Generate some users first to have a pool for orders
        for _ in range(50):
            events.append(self._generate_user_event())
        
        # Generate remaining events
        while len(events) < num_events:
            event_type = random.choice(self.event_types)
            
            if event_type == "order_created":
                events.append(self._generate_order_event())
            elif event_type == "user_registered":
                events.append(self._generate_user_event())
            elif event_type == "product_updated":
                events.append(self._generate_product_event())
            elif event_type == "order_cancelled":
                events.append(self._generate_cancelled_order_event())
        
        # Shuffle events to mix them up
        random.shuffle(events)
        
        # Trim to exact number if we went over
        return events[:num_events]
    
    def save_events(self, events: List[Dict[str, Any]], output_file: str) -> None:
        """Save events to JSON file."""
        with open(output_file, 'w') as f:
            for event in events:
                f.write(json.dumps(event) + '\n')
        
        print(f"Generated {len(events)} events in {output_file}")
        
        # Print statistics
        event_counts = {}
        duplicate_events = 0
        event_ids = []
        
        for event in events:
            event_type = event["event_type"]
            event_counts[event_type] = event_counts.get(event_type, 0) + 1
            
            event_id = event["event_id"]
            if event_id in event_ids:
                duplicate_events += 1
            else:
                event_ids.append(event_id)
        
        print(f"Event type distribution: {event_counts}")
        print(f"Duplicate event_ids: {duplicate_events}")
        print(f"Unique users generated: {len(self.users)}")


def main():
    """Main function to run the data generator."""
    parser = argparse.ArgumentParser(description="Generate synthetic e-commerce events")
    parser.add_argument("--date", required=True, help="Target date in YYYY-MM-DD format")
    parser.add_argument("--events", type=int, default=1000, help="Number of events to generate (default: 1000)")
    parser.add_argument("--output", help="Output file path (default: events_YYYY-MM-DD.jsonl)")
    
    args = parser.parse_args()
    
    try:
        # Validate date format
        datetime.strptime(args.date, "%Y-%m-%d")
    except ValueError:
        print("Error: Invalid date format. Please use YYYY-MM-DD")
        sys.exit(1)
    
    # Set default output filename
    if not args.output:
        args.output = f"events_{args.date}.jsonl"
    
    print(f"Generating {args.events} synthetic e-commerce events for {args.date}")
    
    # Generate events
    generator = EcommerceDataGenerator(args.date)
    events = generator.generate_events(args.events)
    
    # Save events
    generator.save_events(events, args.output)
    
    print("Data generation completed successfully!")


if __name__ == "__main__":
    main()
