#!/usr/bin/env python3
"""
End-to-End Data Integrity Validation Script
Validates data consistency across the ELT pipeline stages.
"""

import psycopg2
from typing import Dict, Any
import sys

def get_db_connection():
    """Establish connection to PostgreSQL database."""
    return psycopg2.connect(
        host='postgres',
        port=5432,
        database='warehouse',
        user='airflow',
        password='airflow'
    )

def validate_raw_to_staging_deduplication(conn) -> Dict[str, Any]:
    """
    Check if the number of records in raw.events_stream matches the number 
    of records in stg_events (after accounting for duplicates).
    """
    print("🔍 Validating raw to staging deduplication...")
    
    with conn.cursor() as cursor:
        # Get raw event count
        cursor.execute("SELECT COUNT(*) FROM raw.events_stream")
        raw_count = cursor.fetchone()[0]
        
        # Get unique event count from raw (should match staging)
        cursor.execute("""
            SELECT COUNT(DISTINCT id) 
            FROM raw.events_stream
        """)
        raw_unique_count = cursor.fetchone()[0]
        
        # Get staging event count (unique events)
        cursor.execute("SELECT COUNT(DISTINCT event_id) FROM analytics_staging.stg_events WHERE event_id IS NOT NULL")
        staging_unique_count = cursor.fetchone()[0]
        
        # Calculate duplicates removed
        duplicates_removed = raw_count - staging_unique_count
        deduplication_rate = (duplicates_removed / raw_count * 100) if raw_count > 0 else 0
        
        print(f"   Raw records: {raw_count:,}")
        print(f"   Raw unique records: {raw_unique_count:,}")
        print(f"   Staging unique records: {staging_unique_count:,}")
        print(f"   Duplicates removed: {duplicates_removed:,} ({deduplication_rate:.2f}%)")
        
        # Validation check - staging should have unique events from raw
        is_valid = (staging_unique_count <= raw_unique_count)
        
        if is_valid:
            print("   ✅ PASS: Staging unique count is valid (≤ raw unique count)")
        else:
            print(f"   ❌ FAIL: Staging unique count ({staging_unique_count}) > Raw unique count ({raw_unique_count})")
        
        return {
            "test_name": "Raw to Staging Deduplication",
            "passed": is_valid,
            "raw_count": raw_count,
            "raw_unique_count": raw_unique_count,
            "staging_unique_count": staging_unique_count,
            "duplicates_removed": duplicates_removed,
            "deduplication_rate_pct": round(deduplication_rate, 2)
        }

def validate_order_id_integrity(conn) -> Dict[str, Any]:
    """
    Verify that all order_ids in fact_orders exist in the raw data.
    """
    print("\n🔍 Validating order_id integrity...")
    
    with conn.cursor() as cursor:
        # Get all order_ids from fact_orders
        cursor.execute("""
            SELECT DISTINCT order_id 
            FROM analytics_marts.fact_orders 
            WHERE order_id IS NOT NULL
        """)
        fact_order_ids = {row[0] for row in cursor.fetchall()}
        
        # Get all order_ids from raw data
        cursor.execute("""
            SELECT DISTINCT data->>'order_id' 
            FROM raw.events_stream 
            WHERE data->>'order_id' IS NOT NULL
        """)
        raw_order_ids = {row[0] for row in cursor.fetchall()}
        
        # Find order_ids in fact but not in raw
        missing_in_raw = fact_order_ids - raw_order_ids
        extra_in_fact = fact_order_ids - raw_order_ids
        
        print(f"   Fact orders: {len(fact_order_ids):,}")
        print(f"   Raw orders: {len(raw_order_ids):,}")
        print(f"   Orders missing in raw: {len(missing_in_raw):,}")
        
        # Show some examples if there are issues
        if missing_in_raw and len(missing_in_raw) <= 5:
            print(f"   Missing order_ids: {list(missing_in_raw)}")
        elif missing_in_raw:
            print(f"   Sample missing order_ids: {list(missing_in_raw)[:5]}...")
        
        # Validation check
        is_valid = len(missing_in_raw) == 0
        
        if is_valid:
            print("   ✅ PASS: All fact order_ids exist in raw data")
        else:
            print(f"   ❌ FAIL: {len(missing_in_raw)} order_ids in fact_orders not found in raw data")
        
        return {
            "test_name": "Order ID Integrity",
            "passed": is_valid,
            "fact_order_count": len(fact_order_ids),
            "raw_order_count": len(raw_order_ids),
            "missing_in_raw_count": len(missing_in_raw),
            "missing_order_ids": list(missing_in_raw)[:10] if missing_in_raw else []  # Limit to first 10
        }

def validate_user_id_consistency(conn) -> Dict[str, Any]:
    """
    Validate user_id consistency across stages.
    """
    print("\n🔍 Validating user_id consistency...")
    
    with conn.cursor() as cursor:
        # Get user counts from different stages
        cursor.execute("""
            SELECT COUNT(DISTINCT data->>'user_id') 
            FROM raw.events_stream 
            WHERE data->>'user_id' IS NOT NULL
        """)
        raw_user_count = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(DISTINCT user_id) 
            FROM analytics_staging.stg_events 
            WHERE user_id IS NOT NULL
        """)
        staging_user_count = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(DISTINCT user_id) 
            FROM analytics_marts.fact_orders 
            WHERE user_id IS NOT NULL
        """)
        fact_user_count = cursor.fetchone()[0]
        
        print(f"   Raw users: {raw_user_count:,}")
        print(f"   Staging users: {staging_user_count:,}")
        print(f"   Fact users: {fact_user_count:,}")
        
        # Validation check - staging should match raw, fact should be subset
        users_consistent = (staging_user_count == raw_user_count)
        fact_subset = (fact_user_count <= staging_user_count)
        
        is_valid = users_consistent and fact_subset
        
        if is_valid:
            print("   ✅ PASS: User counts are consistent across stages")
        else:
            if not users_consistent:
                print("   ❌ FAIL: Staging user count doesn't match raw")
            if not fact_subset:
                print("   ❌ FAIL: Fact user count exceeds staging")
        
        return {
            "test_name": "User ID Consistency",
            "passed": is_valid,
            "raw_user_count": raw_user_count,
            "staging_user_count": staging_user_count,
            "fact_user_count": fact_user_count
        }

def validate_data_freshness(conn) -> Dict[str, Any]:
    """
    Check data freshness across tables.
    """
    print("\n🔍 Validating data freshness...")
    
    with conn.cursor() as cursor:
        # Get latest timestamps from each stage
        cursor.execute("""
            SELECT MAX(processed_at) 
            FROM raw.events_stream
        """)
        raw_latest = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT MAX(event_timestamp) 
            FROM analytics_staging.stg_events
        """)
        staging_latest = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT MAX(order_timestamp) 
            FROM analytics_marts.fact_orders
        """)
        fact_latest = cursor.fetchone()[0]
        
        print(f"   Raw latest: {raw_latest}")
        print(f"   Staging latest: {staging_latest}")
        print(f"   Fact latest: {fact_latest}")
        
        # Check if data is recent (within last 7 days)
        from datetime import datetime, timedelta
        seven_days_ago = datetime.now() - timedelta(days=7)
        
        raw_fresh = raw_latest and raw_latest >= seven_days_ago
        staging_fresh = staging_latest and staging_latest >= seven_days_ago
        fact_fresh = fact_latest and fact_latest >= seven_days_ago
        
        is_valid = raw_fresh and staging_fresh and fact_fresh
        
        if is_valid:
            print("   ✅ PASS: All tables have recent data")
        else:
            print("   ❌ FAIL: Some tables have stale data")
        
        return {
            "test_name": "Data Freshness",
            "passed": is_valid,
            "raw_latest": str(raw_latest),
            "staging_latest": str(staging_latest),
            "fact_latest": str(fact_latest)
        }

def main():
    """Run all E2E validation tests."""
    print("🚀 Starting End-to-End Data Integrity Validation\n")
    
    results = []
    
    try:
        # Connect to database
        conn = get_db_connection()
        print("✅ Database connection established\n")
        
        # Run all validation tests
        test_functions = [
            validate_raw_to_staging_deduplication,
            validate_order_id_integrity,
            validate_user_id_consistency,
            validate_data_freshness
        ]
        
        for test_func in test_functions:
            try:
                result = test_func(conn)
                results.append(result)
            except Exception as e:
                print(f"❌ ERROR in {test_func.__name__}: {e}")
                results.append({
                    "test_name": test_func.__name__,
                    "passed": False,
                    "error": str(e)
                })
        
        # Summary
        print("\n" + "="*60)
        print("📊 VALIDATION SUMMARY")
        print("="*60)
        
        passed_count = sum(1 for r in results if r["passed"])
        total_count = len(results)
        
        for result in results:
            status = "✅ PASS" if result["passed"] else "❌ FAIL"
            print(f"{status} {result['test_name']}")
        
        print(f"\nOverall: {passed_count}/{total_count} tests passed")
        
        if passed_count == total_count:
            print("🎉 ALL TESTS PASSED - Data integrity is validated!")
            return 0
        else:
            print("⚠️  SOME TESTS FAILED - Review the issues above")
            return 1
            
    except Exception as e:
        print(f"❌ CRITICAL ERROR: {e}")
        return 1
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    sys.exit(main())
